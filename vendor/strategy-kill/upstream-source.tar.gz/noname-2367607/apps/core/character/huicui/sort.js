const characterSort = {
	sp_baigei: ["re_panfeng", "xingdaorong", "caoxing", "re_chunyuqiong", "xiahoujie", "dc_caiyang", "zhoushan", "dc_xiahouen"],
	sp_caizijiaren: ["dc_xiahouxuan", "dc_kongrong", "re_dongbai", "re_sunluyu", "heyan", "zhaoyan", "wangtao", "wangyue", "zhangxuan", "tengyin", "zhangyao", "xiahoulingnv", "dc_sunru", "pangshanmin", "kuaiqi"],
	sp_zhilan: ["jimiaojimu", "dc_huangwudie", "dc_liuli", "liuyong", "wanniangongzhu", "zhanghu", "lvlingqi", "tenggongzhu", "panghui", "dc_zhaotongzhaoguang", "yuantanyuanxiyuanshang", "yuechen", "panghong"],
	sp_guixin: ["mamiao", "zangba", "re_kanze", "re_chendeng", "caimaozhangyun", "dc_lvkuanglvxiang", "dc_gaolan", "yinfuren", "chengui", "chenjiao", "dc_sp_jiaxu", "qinlang", "dc_dongzhao", "houcheng"],
	sp_daihan: ["mamidi", "dc_jiling", "zhangxun", "dc_yuejiu", "leibo", "qiaorui", "dongwan", "yuanyin"],
	sp_jianghu: ["dc_zhangshiping", "guanning", "huzhao", "dc_huangchengyan", "mengjie", "wanglie"],
	sp_zongheng: ["huaxin", "luyusheng", "re_xunchen", "re_miheng", "fengxi", "re_dengzhi", "dc_yanghu", "zongyu"],
	sp_taiping: ["guanhai", "liupi", "peiyuanshao", "zhangchu", "zhangkai", "dc_zhangmancheng"],
	sp_yanhan: ["dc_zhugejun", "dc_xiangchong", "dc_lifeng", "dc_liuba", "dc_huangquan", "furongfuqian", "xianglang", "dc_huojun", "gaoxiang", "dc_wuban", "jiangfei", "dc_zhangyì", "dc_feiyi"],
	sp_jishi: ["dc_jiben", "zhenghun", "dc_sunhanhua", "liuchongluojun", "wupu"],
	sp_raoting: ["dc_weifeng", "dc_huanghao", "dc_sunziliufang", "dc_sunchen", "dc_jiachong"],
	sp_yijun: ["gongsundu", "mengyou", "dc_sp_menghuo", "gongsunxiu", "dc_sp_zhurong", "dc_mateng", "dc_muludawang"],
	sp_zhengyin: ["yue_caozhi", "yue_zhouyu", "yue_diaochan", "yue_caiwenji", "yue_zhoufei", "yue_caiyong", "yue_xiaoqiao", "yue_daqiao", "yue_miheng", "yue_zoushi", "yue_zhugeguo"],
	huicui_waitforsort: [],
};

const characterSortTranslate = {
	sp_baigei: "无双上将",
	sp_caizijiaren: "才子佳人",
	sp_zhilan: "芝兰玉树",
	sp_zongheng: "纵横捭阖",
	sp_guixin: "天下归心",
	sp_jianghu: "江湖之远",
	sp_daihan: "代汉涂高",
	sp_taiping: "太平甲子",
	sp_yanhan: "匡鼎炎汉",
	sp_jishi: "悬壶济世",
	sp_raoting: "绕庭之鸦",
	sp_yijun: "异军突起",
	sp_zhengyin: "正音雅乐",
	huicui_waitforsort: "等待分包",
};

export { characterSort, characterSortTranslate };
