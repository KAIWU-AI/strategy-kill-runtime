const characterSort = {
	clan_wu: ["clan_wuyi", "clan_wuxian", "clan_wuban", "clan_wukuang", "clan_wuqiao"],
	clan_xun: ["clan_xunshi", "clan_xunshu", "clan_xunchen", "clan_xuncai", "clan_xuncan", "clan_xunguan", "clan_xunyou", "clan_xunshuang", "clan_xunyu"],
	clan_zhuge: ["clan_zhugeguo", "clan_zhugezhan"],
	clan_han: ["clan_hanshao", "clan_hanrong", "clan_hanfu"],
	clan_wang: ["clan_wangshen", "clan_wangling", "clan_wangyun", "clan_wanghun", "clan_wanglun", "clan_wangguang", "clan_wangmingshan", "clan_wangchang"],
	clan_zhong: ["clan_zhongyan", "clan_zhonghui", "clan_zhongyu", "clan_zhongyao"],
	clan_yang: ["clan_yangci", "clan_yangxiu", "clan_yangzhong", "clan_yangbiao"],
	clan_lu: ["clan_luji", "clan_lujing", "clan_luyusheng", "clan_lutan"],
	clan_chen: ["clan_chenqun", "clan_chentai"],
};

const characterSortTranslate = {
	clan_wu: "陈留·吴氏",
	clan_xun: "颍川·荀氏",
	clan_zhuge: "琅琊·诸葛氏",
	clan_han: "颍川·韩氏",
	clan_wang: "太原·王氏",
	clan_zhong: "颍川·钟氏",
	clan_yang: "弘农·杨氏",
	clan_lu: "吴郡·陆氏",
	clan_chen: "颍川·陈氏",
};

export { characterSort, characterSortTranslate };
